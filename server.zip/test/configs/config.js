module.exports = {
	"baseURL" : "/api/private/v1/",
	"username" : "admin",
	"password" : "123456"
}